package com.cap.ui;

import java.util.InputMismatchException;
import java.util.Iterator;
import java.util.List;
import java.util.ListIterator;
import java.util.Scanner;

import com.cap.Exception.AccountNotFoundException;
import com.cap.bean.BankDetail;
import com.cap.bean.BankTransaction;
import com.cap.service.BankService;
import com.cap.service.BankServiceImp;

public class MainUi {
		
	static BankService service = new BankServiceImp(); // we are giving the reference to the interface but creating the object pf subclass to hide the data
	static Scanner scanner=new Scanner(System.in);

	public static void main(String[] args) {
		
		
		while(true){
			System.out.println("\n\n\nWelcome to the bank application");
			System.out.println("1.Create Account");
			System.out.println("2.Show Balance");
			System.out.println("3.Deposit");
			System.out.println("4.Withdraw");
			System.out.println("5.Fund Transfer");
			System.out.println("6.Print Transaction");
			System.out.println("7.Exit");

			
			System.out.println("Enter your choice");
			 int a= scanner.nextInt();
		        switch(a)
		        {
		        case 1 : //case1 for creating the account
		        	try{
		        	boolean isOkName = false;
		        	System.out.println("Enter the name :");
	        		String name;
	        		do{ //validation for names to be alphabets starting with capital letter
	        			name=scanner.next();
	        			isOkName = service.isOkayName(name);
	        			
	        			if(!isOkName){
	        				System.out.println("Please Enter Alphabets starting with Capital Letter Only");
	        				System.out.println("Enter the name");

	        			}
	        		} while(!isOkName);
	        		System.out.println("Enter the  branch name :");
	        		String branch = scanner.next();
	        		boolean isOkType= false;
	        		System.out.println("Enter the account type Savings / Current :");
	        		String accountType; 
	        		do{ //validation for the account type to be savings or current only
	        			accountType=scanner.next();
	        			isOkType = service.accountTypeValidate(accountType);
	        			
	        			if(!isOkType){
	        				System.out.println("Please Enter The Account Type As SAVINGS Or CURRENT . ");
	        			    System.out.println("Enter the account type Savings / Current");}
	        		}while(!isOkType);
	        		boolean isOkNumber = false;
	        		System.out.println("Enter the mobile number :");
	        		long mobileno;
	        		
	        		do{ //validation for mobile number to be 10 digits only starting with 6-9
	        			mobileno=scanner.nextLong();
	        			isOkNumber = service.isOkayNumber(mobileno);
	        			
	        			if(!isOkNumber){
	        				System.out.println("Please Enter 10 digits number only");
	        				System.out.println("Enter the mobile number");

	        			}
	        		} while(!isOkNumber);

	        		System.out.println("Enter the balance");
	        		int balance = scanner.nextInt();
	        		
	        		
		        	BankDetail bank = new BankDetail();
		        	bank.setName(name);
                    bank.setAccountType(accountType);
		        	bank.setBranch(branch);
		        	bank.setBalance(balance);
		        	bank.setMobileno(mobileno);
		        	
		        	
		        	
		        	long accountno=service.insertBankDetails(bank);
		        	
		    		System.out.println("****CONGRATULATIONS! YOUR  ACCOUNT IS CREATED****");
		    		System.out.println("Account number = " + accountno);
		        	}catch(AccountNotFoundException ae){ //Exception handling if account number is missing
		        		System.out.println("Account Not Found");}
		        		catch(InputMismatchException e){ //Input mismatch exception handling
		        			System.out.println("Please Enter Your mobile number in numerical format");
		        		}
		        	
		        
		    		break;
		    		
		        case 2: //case2 for showing the available balance in the account
		        	
		        	try{
		        	System.out.println("Fetching Bank Details");

	            	System.out.println("Enter your account number :");
	        		long accountno1= scanner.nextLong();
	            	BankDetail bankers = service.showBalance(accountno1);
	            	System.out.println("your balance is:" + bankers.getBalance());
	        		System.out.println("\n\n\n");
		        	}catch(AccountNotFoundException ae){ //Exception handling if account number is missing
		        		System.out.println(ae.getMessage());
		        	}
		        	
	        		break;
		        	
		        	
		        case 3: //case3 for depositing amount in the account
		        	try{
		        	System.out.println("Enter your account number :");
	        		long accountno2= scanner.nextLong();
		        	System.out.println("Enter the deposit amount");
		        	int depositAmount= scanner.nextInt();
		        	long bal = service.depositMoney(accountno2 , depositAmount); //method call from service class to retrieve properties
		        	System.out.println("Your account has been succesfully credited");
	            	System.out.println("your new balance is:" + bal);
		        }catch(AccountNotFoundException ae){ //Exception handling if account number is missing
	        		System.out.println(ae.getMessage());
	        	}
		        	break;
		        	
		        	
		        case 4: //case4 for withdrawing amount from the account
		        	try{
		        	System.out.println("Enter your account number :");
	        		long accountno3= scanner.nextLong();
		        	System.out.println("Enter the withdrawal amount");
		        	int withdrawAmount= scanner.nextInt();
		        	long bal1 = service.withrawMoney(accountno3, withdrawAmount);
		        	System.out.println("Your account has been succesfully debited");
	            	System.out.println("your remaining balance is:" + bal1);
		        	}catch(AccountNotFoundException ae){ //Exception handling if account number is missing
		        		System.out.println(ae.getMessage());
		        	}
		        	break;
		        	
		        	
		        case 5: //case5 for transferring funds from one account to another
		        	try{
		        	System.out.println("Enter the first account number from which you want to transfer");
		        	long firstAccount = scanner.nextLong();
		        	System.out.println("Enter the second account number to which you want to transfer");
		        	long secondAccount =  scanner.nextLong();
		        	System.out.println("Enter the amount you want to transfer");
		        	int amount = scanner.nextInt();
		        	long remainingBalance= service.transferFunds(firstAccount , secondAccount ,amount);
		        	System.out.println("Amount succesfully transfered \n Remaining Balance is in your account :" +remainingBalance);
		        	}catch(AccountNotFoundException ae){ //Exception handling if account number is missing
		        		System.out.println(ae.getMessage());
		        	}
		        	break;
		        case 6: //case6 for printing transaction
		            try {
		            	 System.out.println(
		                         "************************************ALL TRANSACTIONS***********************************************************************");

		  

		                 System.out.println(
		                         "---------------------------------------------------------------------------------------------------------------------------");
		                 System.out.printf("%15s %15s %15s %15s %15s %20s", "TRANSACTION ID", "ACCOUNT NO", "TO ACCOUNT",
		                         "OLD BALANCE", "NEW BALANCE", "TRANSACTION TYPE");
		                 System.out.println();
		                 System.out.println(
		                         "---------------------------------------------------------------------------------------------------------------------------");
		                 List<BankTransaction> result = service.printTransaction();
		                 ListIterator<BankTransaction> lis = result.listIterator();
		                 while (lis.hasNext()) // forward direction
		                 {
		                     System.out.println(lis.next() + " ");
		                 }
		                 System.out.println("\n\n\n\n\n\n\n\n");
		                 
	                } catch (Exception e) {
	                    System.out.println("Enter Valid information");
	                }
	                break;
		        	
		        case 7: // case7 for exiting the application
	            	System.out.println("Thank you. Have a nice day .");
	            	System.exit(0);
		        	
		        default:
		        	System.out.println("You have entered a wrong choice. Please ReEnter your Choice");
		        }
      }
	}
}
	
