package com.cap.bean;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table
public class BankDetail { 
	@Column(length=10)
	private String name;
	@Column(length=10)
	private String branch;
	@Column(length=10)
	private long mobileno;
	@Column(length=10)
	private String accountType;
	@Id
	@GeneratedValue
	@Column(length=10)
	private long accountno;
	@Column(length=10)
	private long balance;

	@Override
	public String toString() {
		return "BankDetail [name=" + name + ", branch=" + branch + ", mobileno=" + mobileno + ", accountType="
				+ accountType + ", accountno=" + mobileno + ", balance=" + balance + "]";
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getBranch() {
		return branch;
	}

	public void setBranch(String branch) {
		this.branch = branch;
	}

	public long getMobileno() {
		return mobileno;
	}

	public void setMobileno(long mobileno) {
		this.mobileno = mobileno;
	}

	public String getAccountType() {
		return accountType;
	}

	public void setAccountType(String accountType) {
		this.accountType = accountType;
	}

	public long getAccountno() {
		return accountno;
	}

	public long setAccountno(long accountno) {
		return this.accountno = accountno;
	}

	public long getBalance() {
		return balance;
	}

	public void setBalance(long balance) {
		this.balance = balance;
	}

}
