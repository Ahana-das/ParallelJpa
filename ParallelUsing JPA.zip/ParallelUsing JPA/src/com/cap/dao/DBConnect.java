package com.cap.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DBConnect {
	public static Connection getConnection() {
		Connection conn=null;
		try{
			Class.forName("oracle.jdbc.driver.OracleDriver");
			conn = DriverManager.getConnection("jdbc:oracle:thin:@10.219.34.3:1521:orcl","trg427","training427");
		} catch( ClassNotFoundException | SQLException e){
			e.printStackTrace();
		}
		return conn;
		
	}

}
