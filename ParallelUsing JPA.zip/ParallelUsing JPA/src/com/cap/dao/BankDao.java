package com.cap.dao;

import java.util.List;

import com.cap.bean.BankDetail;
import com.cap.bean.BankTransaction;

public interface BankDao {
	long insertBankDetails(BankDetail bank);

	BankDetail showBalance(long accountno);

	long depositMoney(long accountno, int depositAmount);

	long withdrawMoney(long accountno, int withdrawAmount);

	long transferFunds(long firstAcc, long secondAcc, int transferAmount);

	List<BankTransaction> printTransaction();
	
	void beginTransaction();
	
	void commitTransaction();

}